<?php
function getIcon($fullPath) {
    $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
    if (is_dir($fullPath)) return "📁";
    if ($ext === "php") return "🐘";
    if ($ext === "html" || $ext === "htm") return "🌐";
    if ($ext === "js") return "⚙️";
    if ($ext === "css") return "🎨";
    if (in_array($ext, ["png", "jpg", "jpeg", "gif", "webp"])) return "🖼️";
    if (in_array($ext, ["json", "xml"])) return "📄";
    if (in_array($ext, ["txt", "md"])) return "📝";
    return "📄";
}

$baseDir = __DIR__;
$currentPath = isset($_GET['path']) ? trim($_GET['path'], '/') : '';
$targetDir = realpath($baseDir . '/' . $currentPath);

if (!$targetDir || strpos($targetDir, $baseDir) !== 0) {
    die("Accès refusé.");
}

$files = scandir($targetDir);
$files = array_diff($files, array('.', '..'));

echo '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Explorateur - ' . htmlspecialchars($currentPath) . '</title>
    <style>
        body { font-family: sans-serif; background: #f9f9f9; padding: 30px; }
        h2 { margin-bottom: 20px; }
        ul { list-style: none; padding-left: 20px; }
        li { margin: 6px 0; }
        a { text-decoration: none; color: #333; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <h2>📁 Dossier : /' . htmlspecialchars($currentPath) . '</h2>';

if ($currentPath !== '') {
    $parentPath = dirname($currentPath);
    if ($parentPath === '.' || $parentPath === '/') {
        $parentPath = '';
    }
    $parentLink = $parentPath === '' ? 'index.php' : '?path=' . urlencode($parentPath);
    echo '<p><a href="' . htmlspecialchars($parentLink) . '">⬅ Revenir en arrière</a></p>';
}

echo '<ul>';

foreach ($files as $file) {
    $fullPath = $targetDir . '/' . $file;
    $isDir = is_dir($fullPath);
    $displayName = $file . ($isDir ? '/' : '');
    $icon = getIcon($fullPath); // ✅ Correction ici
    $arrow = $isDir ? '↳ ' : '- ';
    $link = $isDir
        ? '?path=' . urlencode(trim($currentPath . '/' . $file, '/'))
        : ($currentPath !== '' ? $currentPath . '/' . $file : $file);

    echo '<li>' . $arrow . '<a href="' . htmlspecialchars($link) . '">' . $icon . ' ' . htmlspecialchars($displayName) . '</a></li>';
}

echo '</ul>
</body>
</html>';
?>
